package stylecode.kosta180.service;

import java.util.List;

import stylecode.kosta180.domain.ShoppingMallVO;

public interface BookMarkService {
	public List<ShoppingMallVO> bookMarkList(String mId);
	public void deleteBookMark(int spmEnrollNo);

}
