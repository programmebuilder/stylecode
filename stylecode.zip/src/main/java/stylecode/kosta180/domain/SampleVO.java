package stylecode.kosta180.domain;

public class SampleVO {

}
