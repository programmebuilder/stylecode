package stylecode.kosta180.domain;

import java.util.List;

public class SpmFilterListVO {
	private List<Integer> filterList;

	public List<Integer> getFilterList() {
		return filterList;
	}

	public void setFilterList(List<Integer> filterList) {
		this.filterList = filterList;
	}
}
