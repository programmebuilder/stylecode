package stylecode.kosta180.persistence;

public interface SampleDAO {

}
