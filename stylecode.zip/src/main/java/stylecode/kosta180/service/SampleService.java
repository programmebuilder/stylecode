package stylecode.kosta180.service;

public interface SampleService {

}
