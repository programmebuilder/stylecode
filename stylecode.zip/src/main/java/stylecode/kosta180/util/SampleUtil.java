package stylecode.kosta180.util;

public class SampleUtil {

}
