$(document).ready(function(){
    $(".comment-icon-span").click(function(){
        $(".form-control").focus();
    });
    
    $("#commentButton").hide();
});